package com.example.demo.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.Doctor;
import com.example.demo.error.DoctorNotFoundException;
import com.example.demo.repository.DoctorRepository;

@Service
public class DoctorServiceImpl implements DoctorService{
	
	@Autowired
	DoctorRepository doctorRepository;

//************************ADD DOCTOR*************************
	@Override
	public Doctor saveDoctor(Doctor doctor) {
		
		return doctorRepository.save(doctor);
	}

//************************GET ALL DOCTOR*************************
	
	@Override
	public List<Doctor> fetchDoctorList() {
		return doctorRepository.findAll();
	}

//************************DELETE DOCTOR*************************
	
	@Override
	public void deleteDoctorById(Integer did) throws DoctorNotFoundException {
		Optional<Doctor> doc=doctorRepository.findById(did);
		if(!doc.isPresent())
		{
			throw new DoctorNotFoundException("Doctor Id is Not Available Cannot Delete");
		}
		else {
				doctorRepository.deleteById(did);
		}
	}

//************************UPDATE DOCTOR*************************
	
	
	@Override
	public Doctor updateDoctor(Integer did, Doctor doctor) throws DoctorNotFoundException {
		
		Optional<Doctor> doc1=doctorRepository.findById(did);
		Doctor docDB=null;
		if(doc1.isPresent()) {
			 docDB=	doctorRepository.findById(did).get();
			if(Objects.nonNull(doctor.getName()) && !"".equalsIgnoreCase(doctor.getName())) {
				docDB.setName(doctor.getName());
				
			}
			if(Objects.nonNull(doctor.getEmailid()) && !"".equalsIgnoreCase(doctor.getEmailid())) {
				docDB.setEmailid(doctor.getEmailid());
				
			}
			if(Objects.nonNull(doctor.getContactno()) && !"".equalsIgnoreCase(doctor.getContactno())) {
				docDB.setContactno(doctor.getContactno());
				
			}
			if(Objects.nonNull(doctor.getDesignation()) && !"".equalsIgnoreCase(doctor.getDesignation())) {
				docDB.setDesignation(doctor.getDesignation());
				
			}
			if(Objects.nonNull(doctor.getSpeciality()) && !"".equalsIgnoreCase(doctor.getSpeciality())) {
				docDB.setSpeciality(doctor.getSpeciality());
				
			}
			if(Objects.nonNull(doctor.getVisitinghours()) && !"".equalsIgnoreCase(doctor.getVisitinghours())) {
				docDB.setVisitinghours(doctor.getVisitinghours());
				
			}
			if(Objects.nonNull(doctor.getPatient()) && !"".equals(doctor.getPatient())) {
				docDB.setPatient(doctor.getPatient());
				
			}
			
			return doctorRepository.save(docDB);
		}
		else {
			throw new DoctorNotFoundException("Enter Valid Doctor Data to Update the Record");
		}
		

	}

//************************GET DOCTOR DETAILS BY ID*************************
	
	@Override
	public Doctor fetchDoctorById(Integer did) throws DoctorNotFoundException {
			//check for null
			Optional<Doctor> doc1= doctorRepository.findById(did);//check in database
			if(!doc1.isPresent())
			{
				throw new DoctorNotFoundException("Doctor Id is Not available Enter valid ID");
			}
			else
			{
			return doctorRepository.findById(did).get();
			}
	}
	
//***********************GET DOCTOR DETAILS BY NAME*************
	
	@Override
	public Doctor fetchDoctorByName(String name) throws DoctorNotFoundException {
		Optional<Doctor> doc2= doctorRepository.findDoctorByName(name);//check in database
		if(!doc2.isPresent())
		{
			throw new DoctorNotFoundException("Doctor Name is Not available Enter valid Name");
		}
		else
		{
		return doctorRepository.findDoctorByName(name).get();
	}
	}
	
//*******************GET DOCTOR DETAILS BY MAIL ADDRESS*************
	
	@Override
	public Doctor fetchDoctorByEmailid(String emailid) throws DoctorNotFoundException {
		Optional<Doctor> doc2= doctorRepository.findDoctorByEmailid(emailid);
		if(!doc2.isPresent())
		{
			throw new DoctorNotFoundException("Doctor Mail Addresss is not available enter valid Mail Address");
		}
		else {
		return doctorRepository.findDoctorByEmailid(emailid).get();
		}
	}
	

	

}
