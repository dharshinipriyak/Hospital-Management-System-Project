package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.Patient;
import com.example.demo.error.PatientNotFoundException;
import com.example.demo.service.PatientService;

@RestController
public class PatientController {
	
//Inject One class object to Another class using auto wired annotation
	
	@Autowired
	PatientService patientService;
	
/*
 * Patient Can See their Details Using Their Id
 */

//**********************GET PATIENT DETAILS BY ID**************
	
	@GetMapping("/Patient/{id}/")
	public Patient fetchPatientById(@PathVariable("id")Integer aid ) throws PatientNotFoundException 
	{
		
		return patientService.fetchPatientById(aid);
		
	}
}
