package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Doctor;
import com.example.demo.error.DoctorNotFoundException;
import com.example.demo.service.DoctorService;

@RestController
public class DoctorController {
	
//Inject One class object to another class using auto wired annotation
	
	@Autowired
	DoctorService doctorService;

/*
 * Doctor Can
 * 		Get All Doctor Record
 * 		Add New Doctor
 * 		Delete Doctor
 * 		Update Doctor
 * 		Other Doctor Can See Their Data Using their Id, Name and MailAddress
 */
	
//************************ADD DOCTOR*************************
	
	@PostMapping("/AddDoctor/")
	public String doctor(@RequestBody Doctor doctor)
	{
		doctorService.saveDoctor(doctor);
		return "Doctor Record is Inserted Successfully";
	}

//***********************GET ALL DOCTOR**********************	
	
	@GetMapping("/AllDoctor/")
	public List<Doctor> fetchDoctor()
	{
		return doctorService.fetchDoctorList();
	}
	
//************************DELETE DOCTOR**********************
	
	@DeleteMapping("/RemoveDoctor/{id}/")
	public String deleteDoctorById(@PathVariable("id")Integer did) throws DoctorNotFoundException
	{
		doctorService.deleteDoctorById(did);
		return "Doctor is removed from Hospital";
	}

//************************UPDATE DOCTOR**********************
	
	@PutMapping("/UpdateDoctor/{id}/")
	public String updateDoctor(@PathVariable("id") Integer did, @RequestBody Doctor doctor) throws DoctorNotFoundException
	{
		doctorService.updateDoctor(did,doctor);
		return "Doctor record is Updated successfully !!";
	}

//*******************GET DOCTOR DETAILS BY ID*************
	
		@GetMapping("/DoctorById/{id}/")
		public Doctor fetchDoctorById(@PathVariable("id")Integer did ) throws DoctorNotFoundException 
		{
			return doctorService.fetchDoctorById(did);
			
		}

//*******************GET DOCTOR DETAILS BY NAME*************
		
		@GetMapping("/DoctorByName/{name}/")
		public Doctor fetchDoctorByName(@PathVariable("name")String name ) throws DoctorNotFoundException 
		{
			return doctorService.fetchDoctorByName(name);
				
		}
		
//*******************GET DOCTOR DETAILS BY MAIL ADDRESS*************
		
		@GetMapping("/DoctorByMail/{mail}/")
		public Doctor fetchDoctorByEmailid(@PathVariable("mail")String emailid ) throws DoctorNotFoundException 
		{
			return doctorService.fetchDoctorByEmailid(emailid);
				
		}
		
}
