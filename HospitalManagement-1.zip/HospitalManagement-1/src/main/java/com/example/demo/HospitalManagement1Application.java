package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalManagement1Application {

	public static void main(String[] args) {
		SpringApplication.run(HospitalManagement1Application.class, args);
	}

}
