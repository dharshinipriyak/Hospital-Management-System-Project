package com.example.demo.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.Patient;
import com.example.demo.error.PatientNotFoundException;
import com.example.demo.repository.PatientRepository;

@Service
public class PatientServiceImpl implements PatientService{

	@Autowired
	PatientRepository patientRepository;
	

	
//******************GET PATIENT DETAILS BY ID****************
	
	@Override
	public Patient fetchPatientById(Integer aid) throws PatientNotFoundException {
			//check for null
		Optional<Patient> pat= patientRepository.findById(aid);//check in database
		if(!pat.isPresent())
		{
			throw new PatientNotFoundException("Patient Id is Not available Enter valid ID");
		}
		else
		{
		
		return patientRepository.findById(aid).get();
		}
	}

	
	
}
