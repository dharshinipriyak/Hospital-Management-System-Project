package com.example.demo.service;

import java.util.List;
import com.example.demo.entity.Patient;
import com.example.demo.error.PatientNotFoundException;

public interface ReceptionistService {

	Patient savePatient(Patient patient);
	
	void deletePatientById(Integer pid) throws PatientNotFoundException;

	Patient updatePatient(Integer pid, Patient patient) throws PatientNotFoundException;

	List<Patient> fetchPatientList();

	Patient fetchPatientByPname(String pname) throws PatientNotFoundException;

	

}
