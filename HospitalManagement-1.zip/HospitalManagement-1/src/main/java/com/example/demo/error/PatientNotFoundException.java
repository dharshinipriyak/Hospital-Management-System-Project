package com.example.demo.error;

public class PatientNotFoundException extends Exception
{

	private static final long serialVersionUID = -3642012749433417509L;

	public PatientNotFoundException (String s)
	{
		super(s);
	}

}
